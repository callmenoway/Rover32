import SignUpForm from '@/src/components/form/SignUpForm';

const page = () => {
  return (
    <div className='w-full'>
      <SignUpForm />
    </div>
  );
};

export default page;